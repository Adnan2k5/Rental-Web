export const colors = {
  primary: '#4D39EE',
  secondary: '#191B24',
  accent: '#4FC3F7',
  light: '#FAFAFA',
  dark: '#455A64',
};
