import React from "react";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import axios from "axios";

const PayPalCheckout = () => {
    const createOrder = async () => {
        const response = await axios.post("http://localhost:5000/api/create-order", {
            amount: "20.00", // dynamic amount
        });
        return response.data.id;
    };
    const onApprove = async (data, actions) => {
        // You can capture the order here if needed
        alert("Payment successful!");
        console.log("Order Approved: ", data);
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
            <PayPalScriptProvider options={{ "client-id": "AXRC04rbgsIJ0RgoSkJUP7VDDMCQLNNA6traJAbykSdMA_vtwUarX-O6tMnuCkXGbIe5C10a0oJw2jkG" }}>
                <PayPalButtons
                    style={{ layout: "vertical" }}
                    createOrder={(data, actions) => {
                        return createOrder();
                    }}
                    onApprove={onApprove}
                />
            </PayPalScriptProvider>
        </div>
    );
};

export default PayPalCheckout;
